/**
date： 2016-06-29
author： jiansuna
description： 公共方法   
*/
define([], function() {
    //获取url里面所包含的参数
    function getUrlParams(name) {
        if (!name) return;
        var reg = new RegExp("(\\?|^|&|\#)" + name + "=([^&|^#]*)(&|$|#)", "i");
        var r = window.location.hash.substr(1).match(reg);
        if (r) return unescape(r[2]);
        return "";

    }
    //显示提交成功
    function showSubmitSuc() {
        $('#submitSuc').removeClass('hide');
        $('#submitSuc').show();
        $('#submitSuc').fadeOut(2000);
    }



    /********************************绑定事件************************************************************/
    //给选择角色绑定事件
    $('body').on('click', '#industryBox a', function() {
        localStorage.setItem("kx100_industry", $(this).attr('industry'));
        location.href = "#/view/yzj/role";
    });
    //给考勤上下班按钮绑定事件
    $('body').on('click', '#onDuty, #offDuty', function() {
        showSubmitSuc();
    });

    //点击拍照
    $('body').on('click', '#takePic', function() {
        XuntongJSBridge && XuntongJSBridge.call('selectPic', { 'type': 'camera' },
            function(result) {
                alert("结果：" + JSON.stringify(result));
                //将图片填充到页面上
            });
    });

    //点击重新定位
    $('body').on('click', '#resetLocation', function() {
        XuntongJSBridge && XuntongJSBridge.call('getLocation', function(result) {
            $('#detailAds').innerHTML = result.data.addressdetail;
        })
    });

    //点击扫描
    $('body').on('click', '#qrcodeBox', function() {
        XuntongJSBridge && XuntongJSBridge.call("scanQRCode", {
            "needResult": 1
        }, function(result) {
            //将扫描结果填充到input框内
            $('#qrcodeBox').siblings('input').text(result.data.qrcode_str);
        });
    })

})
